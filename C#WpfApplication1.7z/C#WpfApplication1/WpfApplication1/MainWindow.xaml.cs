﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private async void button_up_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Кнопка нажата");
            //int i = 30;
            //do
            //{
                MainCar.RenderTransform.SetValue(659, 39, 148, 589) ;
            //    await Task.Delay(500);
            //    i = i - 2;
            //} while (i > 100);
        }

        private void button_down_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button_left_Click(object sender, RoutedEventArgs e)
        {

        }
        
        private void button_right_Click(object sender, RoutedEventArgs e)
        {

        }
    }
    // Автомобиль
    public class Car
    {
        public Car()
        {
            int posX = 0;
            int posY = 0;
            int [] trace = { 0,0,0,0};
        }
        public Car(int x, int y, int[] trc)
        {
            int posX = x;
            int posY = y;
            //int[] trace = int[] trc;
        }
        /*public Drive(char act)
        {

        }
        */
        ~Car()
        {

        }
    }
    // Светофор
    public class Tlight
    {
        int min_countdown = 5;
        int countdown = 15;
        public Tlight()
        {
            
        }
        public Tlight(int delay)
        {   
            // при нажатии кнопок +1 -1 передается нужное число для увел/умен таймера светофора
            countdown += delay;
        }
       /* public int CountDown()
        {
            // обратный отсчет

        }
        */
        ~Tlight()
        {

        }
    }
}
